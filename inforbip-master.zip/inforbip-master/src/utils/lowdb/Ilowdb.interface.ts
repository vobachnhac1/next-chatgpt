interface ILowDbService {
  initTable(table: string): Promise<any>;
  getListTable(table: string): Promise<any>;
  findAll(table: string): Promise<any>;
  find(condition: object, table: string): Promise<any>;
  update(
    key: string,
    value: string | String,
    table: string,
    dataUpdate: any,
  ): Promise<any>;
  add(record: any, table: string): Promise<any>;
}
