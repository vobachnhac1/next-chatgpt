export class GlobalService {
  static globalCheckCron: any;
  static flagSuccessConnect: boolean;
  static listAccArr: any;
  static checkInsertQueue: boolean;
  static checkUpdateQueue: boolean;
  static checkRunSendDailyInfobip : boolean;
  static checkMoveTableInfobip : boolean;
  static setTimeRunJobMove: string ;
}

export const GetIPAddress = () => {
  var interfaces = require('os').networkInterfaces();
  for (var devName in interfaces) {
    var iface = interfaces[devName];
    for (var i = 0; i < iface.length; i++) {
      var alias = iface[i];
      if (
        alias.family === 'IPv4' &&
        alias.address !== '127.0.0.1' &&
        !alias.internal
      )
        return alias.address;
    }
  }
  return '0.0.0.0';
};

export const CheckJsonValid = (inputST: string) => {
  try {
    JSON.parse(inputST);
  } catch (e) {
    return false;
  }
  return true;
};
