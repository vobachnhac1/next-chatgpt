import {
  Body,
  Controller,
  Get,
  Post,
  ValidationPipe,
  Logger,
  Res,
  HttpStatus,
  Headers,
  HttpException,
} from '@nestjs/common';
import { AccountNewService } from '../services';
import { LowdbService } from 'src/utils';
import { Response } from 'express';
import * as moment from 'moment';
import {
  CheckTempAccount,
  IAccountRes,
  SuggestAccountNumber,
} from '../dto/SuggestAccountNumber.dto';

@Controller('account')
export class AccountNewController {
  constructor(
    private readonly appService: AccountNewService,
    private readonly connectLowDB: LowdbService,
  ) {}

  private readonly logger = new Logger(AccountNewController.name);

  @Get('infoAPI')
  getInfoAPI(): any {
    return this.appService.getInfoAPI();
  }

  /**
   *
   * @param data
   * @param header
   * @param ip
   * @returns
   */
  // CALL SERVER FOS
  @Post('getMktInfo')
  async getMktInfo(
    @Body(ValidationPipe) data: any,
    @Headers() header: any,
  ): Promise<any> {
    const host = header['host'].split(':') || [];
    if (host.length > 0) {
      data.IPPublic = host[0] || '0.0.0.0';
    }
    return await this.appService.getMktInfo(data);
  }

  // Create Table With Name
  @Post('create-table')
  async InitTableLowDB(@Body() data: any): Promise<any> {
    if (!data.tableName || data.tableName.length === 0) {
      throw new HttpException(
        '[ERROR1]: The value of table name invalid',
        HttpStatus.BAD_REQUEST,
      );
    }
    return await this.connectLowDB.initTable(data.tableName);
  }

  // Create Table With Name
  @Get('get-list-table')
  async getListTable(): Promise<any> {
    return await this.connectLowDB.getListTable();
  }

  @Post('searchExit')
  async getSearchAcc(
    @Body(ValidationPipe) data: any,
    @Res() response: Response,
  ): Promise<any> {
    this.logger.log('searchExit || ' + JSON.stringify(data));
    response
      .status(HttpStatus.OK)
      .json(await this.appService.searchAccount(data));
  }

  @Post('suggest-account-number')
  async SuggestNumber(
    @Body() data: SuggestAccountNumber,
  ): Promise<IAccountRes> {
    if (
      !data.birth ||
      !data.citizenId ||
      !data.phone ||
      !data.fosId ||
      typeof data.birth !== 'string' ||
      typeof data.citizenId !== 'string' ||
      typeof data.phone !== 'string' ||
      typeof data.fosId !== 'string'
    ) {
      throw new HttpException(
        {
          data: {},
          message: '[ERR] Please input full information',
          status: 'ERROR',
        },
        HttpStatus.BAD_REQUEST,
      );
    }

    if (
      !moment.default(data.birth, 'YYYYMMDD').isValid() ||
      !/^\d+$/.test(data.phone) ||
      !/^\d+$/.test(data.birth) ||
      data.phone.length !== 10 ||
      data.birth.length !== 8 ||
      (data.citizenId.length !== 9 && data.citizenId.length !== 12)
    ) {
      throw new HttpException(
        {
          data: {},
          message: '[ERR] Please input exactly information',
          status: 'ERROR',
        },
        HttpStatus.BAD_REQUEST,
      );
    }

    return this.appService.SuggestNumber({
      ...data,
      citizenId: data.citizenId.replace(/\D/g, ''),
    });
  }

  @Post('check-temp-exist')
  async CheckTempAccount(@Body() data: CheckTempAccount): Promise<IAccountRes> {
    if (
      !data.accNum ||
      !data.fosId ||
      typeof data.accNum !== 'string' ||
      typeof data.fosId !== 'string' ||
      !/^\d+$/.test(data.fosId) ||
      !/^081C\d{6}$/.test(data.accNum)
    ) {
      throw new HttpException(
        {
          data: {},
          message: '[ERR] Please input exactly information',
          status: 'ERROR',
        },
        HttpStatus.BAD_REQUEST,
      );
    }
    return this.appService.checkTempExist(data);
  }
}
