/* eslint-disable @typescript-eslint/no-var-requires */
import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as moment from 'moment';
import { ServerRequestApi } from 'src/modules/api-infobip/dto/ServerAPI.dto';
import { ServerAPIFosService } from 'src/modules/api-infobip/services';
import { LowdbService, GetIPAddress, GlobalSearch } from 'src/utils';
import {
  CheckTempAccount,
  ISuggestList,
  IAccountRes,
  SuggestAccountNumber,
} from '../dto/SuggestAccountNumber.dto';

const chalk = require('chalk');
const myCache = require('../../../utils/cache');

enum TableDefault {
  accounts = 'accounts',
  hisUpdate = 'hisUpdate', // Thể hiện thời gian gần nhất table cần cập nhật mới.
}

@Injectable()
export class AccountNewService {
  constructor(
    private configService: ConfigService,
    private server: ServerAPIFosService,
    private lowdbService: LowdbService,
  ) {}

  private readonly logger = new Logger(AccountNewService.name);

  getInfoAPI() {
    const resp = {
      company: 'Chứng khoán Shinhan Việt Nam',
      address:
        'Tầng 22, Tòa nhà Centec, 72-74 Nguyễn Thị Minh Khai, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh',
      system: 'API-thrid-partner',
    };
    return resp;
  }

  // API Public test connection
  async getMktInfo(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    // Kiểm tra lịch sử cập nhật danh sách gần nhất
    const rsHisUpt =
      (await this.lowdbService.findAll(TableDefault.hisUpdate)) || [];
    const hisRecord = rsHisUpt.find((item) => item[`${TableDefault.accounts}`]);
    const timeReset =
      this.configService.get<string>('TIME_RESET_CACHE') || '5000';
    const currentDate = moment.default().valueOf();
    const hisDate = moment
      .default(hisRecord[`${TableDefault.accounts}`])
      .add('milliseconds', Number(timeReset))
      .valueOf();

    // dữ liệu table
    let listdata =
      (await this.lowdbService.findAll(TableDefault.accounts)) || [];
    let resultAPI;
    if (moment.default(currentDate).isAfter(moment.default(hisDate))) {
      console.log('>>>>>>>>>> Cập nhật <<<<<<<<<');
      const svApiFmt = new ServerRequestApi();
      svApiFmt.ClientSeq = new Date().getTime();
      svApiFmt.Lang = 'EN';
      svApiFmt.WorkerName = 'FOSqMkt02';
      svApiFmt.Operation = 'Q';
      svApiFmt.ServiceName = 'FOSqMkt02_IndexMgt';
      svApiFmt.InVal = data.InVal;
      svApiFmt.TotInVal = data.TotInVal;
      svApiFmt.IPPrivate = GetIPAddress();
      svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();

      // Thêm thông số không cần thiết nhưng phải khai báo
      resultAPI = await this.server.callSocketFos(svApiFmt);
      //Cập nhật dữ liệu mới vào lowdb
      listdata =
        (await this.lowdbService.addlist(
          resultAPI?.data,
          TableDefault.accounts,
          true,
        )) || [];
    } else {
      console.log('>>>>>>>>>> Dữ liệu mới nhất <<<<<<<<<<<');
    }
    return listdata;
  }

  // Khởi tạo 1 hàm check Rules dưới này
  async getListDataAccounts(): Promise<any> {
    // Kiểm tra lịch sử cập nhật danh sách gần nhất
    const rsHisUpt =
      (await this.lowdbService.findAll(TableDefault.hisUpdate)) || [];

    const hisRecord = rsHisUpt.find((item) => item[`${TableDefault.accounts}`]);

    const timeReset =
      this.configService.get<string>('TIME_RESET_CACHE') || '5000';
    const currentDate = moment.default().valueOf();

    const hisDate = moment
      .default(hisRecord[`${TableDefault.accounts}`])
      .add('milliseconds', Number(timeReset))
      .valueOf();

    // dữ liệu table
    let listdata =
      (await this.lowdbService.findAll(TableDefault.accounts)) || [];
    let resultAPI;
    if (moment.default(currentDate).isAfter(moment.default(hisDate))) {
      console.log('>>>>>>>>>> Cập nhật <<<<<<<<<');
      const svApiFmt = new ServerRequestApi();
      svApiFmt.ClientSeq = new Date().getTime();
      svApiFmt.Lang = 'VI';
      svApiFmt.WorkerName = 'ALTqAccount';
      svApiFmt.Operation = 'Q';
      svApiFmt.ServiceName = 'ALTqAccount_Common_1';
      svApiFmt.InVal = ['wait_account'];
      svApiFmt.TotInVal = 1;
      svApiFmt.IPPrivate = GetIPAddress();
      svApiFmt.IPPublic = GetIPAddress();

      // Thêm thông số không cần thiết nhưng phải khai báo
      resultAPI = await this.server.callSocketHos(svApiFmt);
      //Cập nhật dữ liệu mới vào lowdb
      listdata =
        (await this.lowdbService.addlist(
          resultAPI?.data,
          TableDefault.accounts,
          true,
        )) || [];
    } else {
      console.log('>>>>>>>>>> Dữ liệu mới nhất <<<<<<<<<<<');
    }

    // Xử lý thêm rules: listdata => là danh sách mới nhất trong khoản thời gian TIME_RESET_CACHE

    /*TO DO NAM code begin*/

    /*TO DO NAM code end*/

    return listdata;
  }

  async getHosAcc(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    const svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqAccount';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqAccount_Common_1';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();

    // Thêm thông số không cần thiết nhưng phải khai báo
    return this.server.callSocketHos(svApiFmt);
  }

  //SearchFulltext
  async searchAccount(data: any): Promise<any> {
    this.logger.log(JSON.stringify(data));
    const { accNo } = data;

    console.log(chalk.cyan('<<*Start data search Acc begin*>>'));

    let listAcc = myCache.get('accountCache');

    if (listAcc) {
      console.log('>>>> listAcc cache exit >>>', listAcc);

      const result = await GlobalSearch.searchAcc(accNo);

      return {
        cache: true,
        result: result,
      };
    } else {
      console.log(chalk.bold.red('>>>> listAcc cache not exit >>>'));

      const data = new ServerRequestApi();
      data.InVal = ['wait_account'];
      data.TotInVal = 1;

      const responseResult = await this.getHosAcc(data);

      if (responseResult) {
        const { data } = responseResult;

        console.log(chalk.cyan('<<*Start data get from HOS return begin*>>'));
        console.log('responseResultData ', data);
        console.log(chalk.cyan('<<*Start data get from HOS return end*>>'));

        const setDbR = await this.lowdbService.addlist(
          data,
          TableDefault.accounts,
          true,
        );
        console.log('setDbResult   ', setDbR);

        console.log(chalk.cyan('<<*Start data set Cache begin*>>'));
        const successFlag = myCache.set('accountCache', data, 3000);

        listAcc = myCache.get('accountCache');
        console.log('success Flag Cache >>>   ', successFlag);
        console.log(chalk.cyan('<<*Start data set Cache end*>>'));

        GlobalSearch.globalAccArray = data;
        await GlobalSearch.indexAcc();

        const result = await GlobalSearch.searchAcc(accNo);

        return {
          cache: false,
          result: result,
        };
      }
    }

    console.log(chalk.cyan('<<*Start data search Acc end*>>'));

    return { Successed: false };
  }

  async SuggestNumber(data: SuggestAccountNumber): Promise<IAccountRes> {
    const accounts: { c0: string; id: string }[] =
      (await this.getListDataAccounts()) || [];

    const cacheAccount = myCache.get('tempAccountList') || {};
    const suggestList = {
      phone1: '081C' + data.phone.slice(-6),
      phone2: generatePriorityList(data.phone, 6),

      birth1: '081C' + moment.default(data.birth).format('DDMMYY'),
      birth2: '081C' + moment.default(data.birth).format('YYMMDD'),
      birth3: '081C' + moment.default(data.birth).format('MMYYYY'),

      id1: '081C' + data.citizenId.slice(-6),
      id2: '081C' + data.citizenId.slice(0, 3) + data.citizenId.slice(-3),
      id3: generatePriorityList(data.citizenId, 6),
    };

    function generatePriorityList(value: string, length: number) {
      const priorityList = [];
      for (let i = 0; i < value.length - length; i++) {
        priorityList.push('081C' + value.slice(i, i + length));
      }
      return priorityList;
    }

    const availableSet = new Set(
      Object.values(accounts).map((item) => item.c0),
    );

    for (const key in cacheAccount) {
      if (key !== data.fosId) {
        availableSet.add(cacheAccount[key]);
      }
    }

    function findAvailablePriorities(
      priorities: ISuggestList,
      availableSet: Set<string>,
    ): IAccountRes {
      const result = [];

      const checkPriority = (priority: string) => {
        const values = Array.isArray(priorities[priority])
          ? priorities[priority]
          : [priorities[priority]];
        for (const temp of values) {
          if (!availableSet.has(temp)) {
            if (Array.isArray(priorities[priority])) {
              priorities[priority].splice(
                priorities[priority].indexOf(temp),
                1,
              );
            } else {
              priorities[priority] = null;
            }
            return temp;
          }
        }
        return null;
      };

      const getType = (type: string) => {
        switch (type) {
          case 'phone1':
          case 'phone2':
            return 'phone';
          case 'birth1':
          case 'birth2':
          case 'birth3':
            return 'birth';
          case 'id1':
          case 'id2':
          case 'id3':
            return 'id';
          default:
            return '';
        }
      };

      const priorityGroups = [
        ['phone1', 'phone2'],
        ['birth1', 'birth2', 'birth3'],
        ['id1', 'id2', 'id3'],
      ];

      const fallbackPriorities = [
        ['birth2', 'birth3', 'id2', 'id3'],
        ['phone2', 'id2', 'id3'],
        ['phone2', 'birth2', 'birth3'],
      ];

      for (let i = 0; i < 3; i++) {
        for (const priority of priorityGroups[i]) {
          result[i] = checkPriority(priority);
          if (result[i]) {
            result[i] = {
              accNum: result[i].replace('081C', ''),
              type: getType(priority),
            };
            break;
          }
        }

        if (!result[i]) {
          for (const fallbackPriority of fallbackPriorities[i]) {
            result[i] = checkPriority(fallbackPriority);
            if (result[i]) {
              result[i] = {
                accNum: result[i].replace('081C', ''),
                type: getType(fallbackPriority),
              };
              break;
            }
          }
        }
      }

      const filteredResult = result.filter((item) => item !== null);

      if (filteredResult.length <= 0) {
        throw new HttpException(
          {
            data: [],
            message: '[ERR] Cannot find any suggestions',
            status: 'ERROR',
          },
          HttpStatus.NOT_FOUND,
        );
      }

      return {
        data: filteredResult,
        message: 'SUCCESS',
        status: 'SUCCESS',
      };
    }

    return findAvailablePriorities(suggestList, availableSet);
  }

  async checkTempExist(data: CheckTempAccount): Promise<IAccountRes> {
    const accounts: { c0: string; id: string }[] =
      (await this.getListDataAccounts()) || [];

    const availableSet = new Set(
      Object.values(accounts).map((item) => item.c0),
    );

    if (availableSet.has(data.accNum)) {
      throw new HttpException(
        {
          data: {},
          message: '[ERR] This account number has been chosen by another user',
          status: 'ERROR',
        },
        HttpStatus.CONFLICT,
      );
    }

    const temp: object = myCache.get('tempAccountList') || {};

    for (const key in temp) {
      if (key !== data.fosId && temp[key] === data.accNum) {
        throw new HttpException(
          {
            data: {},
            message:
              '[ERR] This account number has been chosen by another user',
            status: 'ERROR',
          },
          HttpStatus.CONFLICT,
        );
      }
    }

    temp[data.fosId] = data.accNum;

    myCache.set('tempAccountList', temp, 60);

    return {
      data: 'Success',
      message: '[SUCCESS] User can choose this account number',
      status: 'SUCCESS',
    };
  }
}
