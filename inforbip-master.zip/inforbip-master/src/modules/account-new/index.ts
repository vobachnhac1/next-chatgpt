import { Module } from '@nestjs/common';
import { ApiModule } from '../api-infobip';
import { ZeroMqModule } from '../zeromq/zeromq.module';
import * as controllers from './controller';
import * as services from './services';

@Module({
  imports: [ZeroMqModule, ApiModule],
  controllers: Object.values(controllers),
  providers: [...Object.values(services)],
})
export class AccountNewModule {}
