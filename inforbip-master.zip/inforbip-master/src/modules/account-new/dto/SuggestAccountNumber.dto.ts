import { ApiProperty } from '@nestjs/swagger';

export class SuggestAccountNumber {
  @ApiProperty({ description: 'Số điện thoại' })
  phone: string;

  @ApiProperty({ description: 'Ngày sinh' })
  birth: string;

  @ApiProperty({ description: 'CCCD/CMND' })
  citizenId: string;

  @ApiProperty({ description: 'FOS ID' })
  fosId: string;
}

export class CheckTempAccount {
  @ApiProperty({ description: 'Số tài khoản' })
  accNum: string;

  @ApiProperty({ description: 'FOS ID' })
  fosId: string;
}

export interface ISuggestList {
  phone1: string;
  phone2: any[];
  birth1: string;
  birth2: string;
  birth3: string;
  id1: string;
  id2: string;
  id3: any[];
}

export interface IAccountRes {
  data: string[] | string;
  message: string;
  status: string;
}
