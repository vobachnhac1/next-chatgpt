import {
  Body,
  Controller,
  Get,
  Post,
  ValidationPipe,
  Logger,
  Res,
  HttpStatus,
  Headers,
  Ip,
} from '@nestjs/common';
import { ServerToZalo } from '../dto/SendInfo.dto';
import { ApiInfoBipService } from '../services/apiInfobip.service';
import { Response } from 'express';
const chalk = require('chalk');

@Controller('gwInfobip')
export class ApiCmsController {
  constructor(private readonly appService: ApiInfoBipService) {}

  private readonly logger = new Logger(ApiCmsController.name);

  @Get('infoAPI')
  getInfoAPI(): any {
    return this.appService.getInfoAPI();
  }

  // API SEND TO THÔNG TIN INFOBIP
  @Post('sendMessZalo')
  async sendMessageZalo(
    @Body(ValidationPipe) data: ServerToZalo,
    @Res() response: Response,
  ): Promise<any> {

    this.logger.log(chalk.cyan( ' >>>>>>>>>send MessZalo  begin >>>>>>>>>>>>>>>>>>'));

    this.logger.log('sendMessZalo || ' + JSON.stringify(data));

    this.logger.log(
      chalk.cyan('>>>>>>>>>send MessZalo  end >>>>>>>>>>>>>>>>>>'),
    );

    // return await this.appService.sendMessZalo(data)
    response
      .status(HttpStatus.OK)
      .send(await this.appService.sendMessZalo(data));
  }

  // API receive THÔNG TIN INFOBIP
  @Post('receivedMessZalo')
  async receivedMessZalo(
    @Body(ValidationPipe) data: any,
    @Res() response: Response,
  ): Promise<any> {
    // TODO
    this.logger.log(chalk.cyan( ' >>>>>>>>>received MessZalo  begin >>>>>>>>>>>>>>>>>>'));

    this.logger.log(chalk.green('receivedMessZalo || ' + JSON.stringify(data)));

    this.logger.log(
      chalk.cyan('>>>>>>>>>received MessZalo  end >>>>>>>>>>>>>>>>>>'),
    );

    response
      .status(HttpStatus.OK)
      .send(await this.appService.callUptStatusInfoBip(data));
  }

  // CALL SERVER FOS
  @Post('getMktInfo')
  async getMktInfo(
    @Body(ValidationPipe) data: any,
    @Headers() header: any,
    @Ip() ip: any,
  ): Promise<any> {
    // TODO
    const host = header['host'].split(':') || [];
    if (host.length > 0) {
      data.IPPublic = host[0] || '0.0.0.0';
    }
    return await this.appService.getMktInfo(data);
  }

  // CALL SERVER HOS
  @Post('getHOSInfo')
  async getHOSInfo(
    @Body(ValidationPipe) data: any,
    @Headers() header: any,
    @Ip() ip: any,
  ): Promise<any> {
    // TODO
    const host = header['host'].split(':') || [];
    if (host.length > 0) {
      data.IPPublic = host[0] || '0.0.0.0';
    }
    return await this.appService.getHOSTest(data);
  }
}
