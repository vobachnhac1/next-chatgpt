import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ServerToZalo } from '../dto/SendInfo.dto';
import axios from 'axios';
import axiosRetry from 'axios-retry';

// import * as moment from 'moment';
const moment = require('moment');
import { ConfigService } from '@nestjs/config';
import { ServerRequestApi } from '../dto/ServerAPI.dto';
import { ServerAPIFosService } from './serverAPI.service';
import { GetIPAddress } from 'src/utils';

@Injectable()
export class ApiInfoBipService {
  constructor(
    private configService: ConfigService,
    private server: ServerAPIFosService,
  ) {}
  private readonly logger = new Logger(ApiInfoBipService.name);

  getInfoAPI() {
    const resp = {
      company: 'Chứng khoán Shinhan Việt Nam',
      address:
        'Tầng 22, Tòa nhà Centec, 72-74 Nguyễn Thị Minh Khai, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh',
      system: 'API-thrid-partner',
    };
    return resp;
  }

  async sendMessZalo(data: ServerToZalo): Promise<any> {
    // kiểm tra dữ liệu truyền vào
    if(!data){
      throw new HttpException(
        'Dữ liệu không hợp lệ',
        HttpStatus.BAD_REQUEST,
      );
    }
    // Kiểm tra số điện thoại.`
    let listPhone = data.destinations || [];
    if (!listPhone || listPhone.length == 0) {
      throw new HttpException(
        'Vui lòng nhập đủ tin người nhận',
        HttpStatus.BAD_REQUEST,
      );
    }
    listPhone = listPhone.map((item) => {
      if (item.to && item.to.length > 0) {
        item.to =
          item.to?.substring(0, 1) == '0'
            ? '84' + item.to?.substring(1, item.to.length)
            : item.to;
      }
      return item;
    });

    // Tham số gửi qua InfoBip
    const paramSendZalo = {
      messages: [
        {
          sender: this.configService.get<string>('BIP_SENDER'),
          destinations: listPhone,
          content: {
            type: 'TEMPLATE',
            templateName: data.templateName,
            templateData: data.templateData,
          },
          webhooks: {
            delivery: {
              url: data.urlWebhooks,
              intermediateReport: true,
            },
            contentType: 'application/json',
            callbackData: {
              templateName: data.templateName,
            },
          },
        },
      ],
    };

    if (
      this.configService.get<string>('ENV_NODE') == 'development' &&
      this.configService.get<string>('FAKE_INFORBIP') == 'on'
    ) {
      const listResp = [
        {
          statusCode: '200',
          status: 'PENDING',
          descr:'FAKE TEST'
        },
        {
          statusCode: '400',
          status: '',
          descr:'FAKE TEST'
        },
        {
          statusCode: '404',
          status: '',
          descr:'FAKE TEST'
        },
      ];
      return listResp[Math.floor(Math.random() * 3)];
    }

    // Call API InfoBip
    let config = {
      method: 'post',
      baseURL: this.configService.get<string>('BIP_URL_BASE'),
      headers: {
        Authorization:
          'App ' + this.configService.get<string>('BIP_URL_AUTH_APP'),
        'Content-Type': 'application/json',
      },
      data: JSON.stringify(paramSendZalo),
    };
    this.logger.log('config sendMessZalo || ' + JSON.stringify(config));
    try {

      axiosRetry(axios, { retries:  Number(this.configService.get<string>('AXIOS_RETRIES_NUM')) || 3,
        retryDelay: (retryCount) => {
          console.log(`Retry attempt call API sendMessZalo: ${retryCount}`);
          return retryCount * 2000; // time interval between retries
        },
        retryCondition: axiosRetry.isRetryableError});

      const res = await axios(config);
      this.logger.log('Result sendMessZalo || ' + JSON.stringify(res.data));
      if (res.status >= 200 && res.status < 300) {
        // send to server FOS
        const messages = res.data.messages || [];
        let status = '';
        if (messages.length > 0) {
          status = res.data.messages.map((item) => item.status.groupName);
        }
        if( this.configService.get<string>('ENV_NODE') == 'development' &&
          this.configService.get<string>('FAKE_INFORBIP') == 'on'){
          const _rsCall = {
            results:[
                {
                  messageId: paramSendZalo.messages[0].destinations[0].messageId,
                  status: {
                    groupId: Math.floor(Math.random() * 6)
                  }   
                }
            ]
          }
          setTimeout(()=>{
            this.callUptStatusInfoBip(_rsCall)
          },3000)
        }
        return {
          success: 'true',
          statusCode: res.status.toString(),
          status: status.toString(),
        };
      }
      return {
        success: 'false',
        statusCode: res.status.toString(),
        status: '',
      };
    } catch (error) {
      this.logger.log('>>>>>>>>>> sendMessZalo error: ', JSON.stringify(error));
      return {
        success: 'false',
        statusCode: error?.response?.status?.toString(),
        status: 'ERROR',
      };
    }
  }

  async callUptStatusInfoBip(data: any): Promise<any> {
    this.logger.log(JSON.stringify(data));
    const { results } = data;
    if (!results || results.length == 0) {
      throw new HttpException(
        '[ERROR1] Tham số không đúng định dạng',
        HttpStatus.BAD_REQUEST,
      );
    }
    const { messageId, status } = results[0];
    if (!messageId || !status) {
      throw new HttpException(
        '[ERROR2] Tham số không đúng định dạng',
        HttpStatus.BAD_REQUEST,
      );
    }
    let state = '';
    switch (status?.groupId) {
      case 1:
        state = 'W';
        break;
      case 3:
        state = 'Y';
        break;
      case 4: // Expired
        state = 'E';
        break;
      case 5: // Reject
        state = 'R';
        break;
      default:
        state = 'N';
    }
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTxAccount01';
    svApiFmt.Operation = 'U';
    svApiFmt.ServiceName = 'ALTxAccount01_OTT_Zalo_Hook_Update';
    svApiFmt.InVal = [
      messageId.toString(),
      state.toString(),
      moment().format('YYYYMMDDHHmmssSSS'),
    ];
    svApiFmt.TotInVal = 3;
    this.logger.log(JSON.stringify(svApiFmt));

    // Xử lý tracking socket: callSocketFos | api: callApiFos
    try {
      const rs = await this.server.callSocketHos({
        ...svApiFmt,
        ServiceName: 'ALTxAccount01_OTT_Zalo_Hook_Tracking',
        Operation: 'I',
      });
      this.logger.log(
        'ALTxAccount01_OTT_Zalo_Hook_Tracking || ' + JSON.stringify(rs),
      );
      // goi tracking
    } catch (error) {
      this.logger.log(
        'ALTxAccount01_OTT_Zalo_Hook_Tracking || ' + JSON.stringify(error),
      );
    }
    try {
      const rs = await this.server.callSocketHos(svApiFmt);
      if (rs.success) {
        return 'Successed';
      }
      throw new HttpException(
        '[ERROR3] Cập nhật trạng thái thất bại',
        HttpStatus.BAD_REQUEST,
      );
    } catch (error) {
      throw new HttpException('[ERROR4] Timeout', HttpStatus.FORBIDDEN);
    }
  }

  async callUptStatusInfoBipFos(data: any): Promise<any> {
    this.logger.log(JSON.stringify(data));
    const { results } = data;
    if (!results || results.length == 0) {
      throw new HttpException(
        '[ERROR1] Tham số không đúng định dạng',
        HttpStatus.BAD_REQUEST,
      );
    }
    const { messageId, status } = results[0];
    if (!messageId || !status) {
      throw new HttpException(
        '[ERROR2] Tham số không đúng định dạng',
        HttpStatus.BAD_REQUEST,
      );
    }
    let state = '';
    switch (status?.groupId) {
      case 1:
        state = 'W';
        break;
      case 3:
        state = 'Y';
        break;
      case 4: // Expired
        state = 'E';
        break;
      case 5: // Reject
        state = 'R';
        break;
      default:
        state = 'N';
    }
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'FOSxAccount01';
    svApiFmt.Operation = 'U';
    svApiFmt.ServiceName = 'FOSxAccount01_OTT_Zalo_Hook_Update';
    svApiFmt.InVal = [
      messageId.toString(),
      state.toString(),
      moment().format('YYYYMMDDHHmmssSSS'),
    ];
    svApiFmt.TotInVal = 3;
    this.logger.log(JSON.stringify(svApiFmt));

    // Xử lý tracking socket: callSocketFos | api: callApiFos
    try {
      const rs = await this.server.callSocketFos({
        ...svApiFmt,
        ServiceName: 'FOSxAccount01_OTT_Zalo_Hook_Tracking',
        Operation: 'I',
      });
      this.logger.log(
        'FOSxAccount01_OTT_Zalo_Hook_Tracking || ' + JSON.stringify(rs),
      );
      // goi tracking
    } catch (error) {
      this.logger.log(
        'FOSxAccount01_OTT_Zalo_Hook_Tracking || ' + JSON.stringify(error),
      );
    }
    try {
      const rs = await this.server.callSocketFos(svApiFmt);
      if (rs.success) {
        return 'Successed';
      }
      throw new HttpException(
        '[ERROR3] Cập nhật trạng thái thất bại',
        HttpStatus.BAD_REQUEST,
      );
    } catch (error) {
      throw new HttpException('[ERROR4] Timeout', HttpStatus.FORBIDDEN);
    }
  }

  // API Public test connection
  async getMktInfo(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'FOSqMkt02';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'FOSqMkt02_IndexMgt';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();

    // Thêm thông số không cần thiết nhưng phải khai báo
    const result = await this.server.callSocketFos(svApiFmt);
    console.log('result: ', result);
    return result;
  }

  // API Public test connection
  async getHOSTest(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqCommon02';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqCommon02_Get_Time';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 45;

    // Thêm thông số không cần thiết nhưng phải khai báo
    return this.server.callSocketHos(svApiFmt);
  }
}
