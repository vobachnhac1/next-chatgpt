import { ApiProperty } from '@nestjs/swagger';

export class ServerToZalo implements ContentSendMessZalo {
  @ApiProperty({ description: 'Dạng template' })
  type: string;

  @ApiProperty({ description: 'Mã template Zalo' })
  templateName: number;

  @ApiProperty({ description: 'Tham số gửi kèm' })
  templateData: Object;

  @ApiProperty({ description: 'Danh sách người nhận' })
  destinations: InfoDestinationMessZalo[];

  @ApiProperty({ description: 'Url webhooks callback' })
  urlWebhooks: string;
}

class ContentSendMessZalo {
  @ApiProperty({ description: 'Dạng template' })
  type: string;

  @ApiProperty({ description: 'Mã template Zalo' })
  templateName: number;

  @ApiProperty({ description: 'Danh sách người nhận' })
  templateData: Object;
}

class InfoRecievedMessZalo {
  @ApiProperty({ description: 'Số điện thoại' })
  to: string;
  @ApiProperty({ description: 'Mã tin nhắn' })
  messageId: string;
}

export type InfoDestinationMessZalo = {
  to: string;
  messageId: string;
};
//R5881: Get information destination
// export class InfoDestinationMessZalo {
//   @ApiProperty({ description: 'Số điện thoại' })
//   to: string;
//   @ApiProperty({ description: 'Mã tin nhắn' })
//   messageId: string;
// }
