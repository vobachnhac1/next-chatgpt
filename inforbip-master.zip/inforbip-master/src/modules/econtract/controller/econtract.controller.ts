import {
  Body,
  Controller,
  Get,
  Post,
  ValidationPipe,
  Logger,
  Res,
  HttpStatus,
  Headers,
  Ip
} from "@nestjs/common";

import { Response } from "express";

import { EcontractServiceService } from "../services/econtract.service";
import { CallCancelEcontractDto } from "../dto/econtractAPPI.dto";


const chalk = require("chalk");

@Controller("gwEcontract")
export class EcontractController {
  constructor(private readonly appService: EcontractServiceService) {
  }

  private readonly logger = new Logger(EcontractController.name);

  @Get("infoAPI")
  getInfoAPI(): any {
    return this.appService.getInfoAPI();
  }

  @Get("getToken")
  getToken(): any {
    return this.appService.getToken();
  }


  @Get("getAllTemplate")
  getAllTemplate(): any {
    return this.appService.getAllTemplateEcontract();
  }

  @Post("callCancelEcontract")
  callCancelEcontract(@Body() data): any {

    return this.appService.callPostCancel(data);
  }


}
