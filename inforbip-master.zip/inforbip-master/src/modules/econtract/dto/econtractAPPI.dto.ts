import * as moment from 'moment';
import { ApiProperty } from '@nestjs/swagger';

export class CallCancelEcontractDto {
  @ApiProperty({ description: 'Keylink' })
  keyLink: string;

  @ApiProperty({ description: 'envID' })
  envID: string;
}

export class BodyTag {
  customData: CustomDataTag[];
  inputData: InputDataTag;
}

export class CustomDataTag {
  recipientId: string;
  email: string;
  telephoneNumber: string;
  contactId: string;
  personalName: string;
  location: string;
  stateOrProvince: string;
  country: string;
  personalID: string;
  passportID: any;
  type: string;
  photoIDCard: any;
  photoIDCardContentType: any;
  photoFrontSideIDCard: string;
  photoFrontSideIDCardContentType: string;
  photoBackSideIDCard: string;
  photoBackSideIDCardContentType: string;
  statusCode: string;
  resourceType: string;
  provideAddress: string;
  provideDate: string;
  commune: string;
  refId: string;
  address: string;
}

export class DatasTag {
  id: string;
  name: string;
  type: string;
  value: string;
  owner: string;
  dataType: string;
  required: boolean;
}

export class InputDataTag {
  templateId: string;
  alias: string;
  syncType: string;
  datas: DatasTag[][];
}

export class FptTemplateGen {
  id: string;
  refId: string;
  selector: string;
  lookup: string;
  attrs: any;
  payload: string;
  body: BodyTag;
}

export class AccountNumberSplit {
  hd1: string;
  hd2: string;
  hd3: string;
  hd4: string;
  hd5: string;
  hd6: string;
}

export class FptToken {
  private tokenSt: string;
  private expireDt: string;

  constructor(tokenSt: string, expireDt: string) {
    this.tokenSt = tokenSt;
    this.expireDt = expireDt;
  }

  public getToken = (): string => {
    return this.tokenSt;
  };

  public getExpireDt = (): string => {
    return this.expireDt;
  };

  public checkExpire = (): boolean => {
    console.log('***Check Token expire begin****');
    let flag = false;

    let tokenDate = moment.default(this.expireDt);

    if (!tokenDate.isValid()) flag = true;

    let now = moment.default();

    if (now > tokenDate) {
      console.log('Token expire >>> ' + tokenDate);
      flag = true;
    }

    console.log('***Check Token expire result is >>' + flag + '<< end****');

    return flag;
  };
}

export class FptTemplateContract {
  templateId: string;
  alias: string;
  syncType: any;
  datas?: AttrA[][];

  constructor(
    templateId: string = '',
    alias: string = '',
    syncType: any = null,
  ) {
    this.templateId = templateId;
    this.alias = alias;
    this.syncType = syncType;
  }
}

export class AttrA {
  id: string;
  name: string;
  type: string;
  value?: string;
  owner: string;
  dataType: string;
  required: boolean;
}
