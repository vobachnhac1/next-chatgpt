import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import axios from 'axios';
import axiosRetry from 'axios-retry';

const moment = require('moment');
import { ConfigService } from '@nestjs/config';
import * as path from 'path';
import * as fs from 'fs';
import {
  AccountNumberSplit,
  FptTemplateContract,
  FptTemplateGen,
  FptToken,
} from '../dto/econtractAPPI.dto';
import * as buffer from 'buffer';
import https from 'https';
import { error } from 'winston';
const _ = require('lodash');

const pathJson = path.join(process.cwd(), './token/token.json');
const pathTemplateJson = path.join(process.cwd(), './template/');

@Injectable()
export class EcontractServiceService {
  constructor(private configService: ConfigService) {}

  private readonly logger = new Logger(EcontractServiceService.name);

  getInfoAPI() {
    const resp = {
      company: 'Chứng khoán Shinhan Việt Nam Econtract',
      address:
        'Tầng 22, Tòa nhà Centec, 72-74 Nguyễn Thị Minh Khai, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh',
      system: 'API-thrid-partner',
    };
    return resp;
  }

  private setMemCache = (tokenStore: FptToken): Promise<any> => {
    return new Promise(async (resolve) => {
      try {
        let data = JSON.stringify(tokenStore);
        console.log(data);

        this.logger.log('pathJson ' + pathJson);

        fs.writeFileSync(pathJson, data);
        this.logger.log('Store Token ok');
        return resolve('ok');
      } catch (error) {
        this.logger.log('Store Token Error');
        this.logger.log(error);
        resolve(error);
      }
    }).catch((error) => {
      this.logger.log(error);
    });
  };

  private readMemCache = async (): Promise<FptToken> => {
    return new Promise(async (resolve) => {
      try {
        if (fs.existsSync(pathJson)) {
          this.logger.log('pathJson ok ');

          await fs.readFile(pathJson, (err: any, data: any) => {
            let dataR = JSON.parse(data);
            if (
              dataR &&
              dataR.hasOwnProperty('tokenSt') &&
              dataR.hasOwnProperty('expireDt')
            ) {
              this.logger.log('Set value from token cache');
              resolve(new FptToken(dataR.tokenSt, dataR.expireDt));
            }
          });
        } else {
          resolve(new FptToken('', ''));
        }
      } catch (error) {
        this.logger.log(error);
        resolve(new FptToken('', ''));
      }
    });
  };

  async getToken() {
    let resp = {
      tokenSave: true,
      dateExpire: '',
    };

    const urlLogin = this.configService.get<string>('URL_LOGIN') || '';

    const dataAuth = JSON.stringify({
      clientid: this.configService.get<string>('CLIENT_ID') || '',
      clientsecret: this.configService.get<string>('CLIENT_SECRET') || '',
      username: this.configService.get<string>('USERNAME_ECONTRACT') || '',
      password: this.configService.get<string>('PASSWORD_ECONTRACT') || '',
    });

    this.logger.log(JSON.stringify(dataAuth));

    const configCall = {
      method: 'post',
      url: urlLogin,
      headers: {
        'Content-Type': 'application/json',
      },
      data: dataAuth,
    };

    this.logger.log('configCall');
    this.logger.log(JSON.stringify(configCall));

    try {
      axiosRetry(axios, {
        retries: 3, // number of retries
        retryDelay: (retryCount) => {
          console.log(`Retry attempt call API Econtract: ${retryCount}`);
          return retryCount * 2000; // time interval between retries
        },
        retryCondition: axiosRetry.isRetryableError,
      });

      const res = await axios(configCall);

      this.logger.log('Result Token' + JSON.stringify(res.data));
      if (res && res.status && res.status >= 200 && res.status < 300) {
        let responseData = res.data;
        if (responseData && responseData.hasOwnProperty('access_token')) {
          const token = responseData.hasOwnProperty('access_token');

          const tokenStore = new FptToken(
            responseData.access_token,
            responseData.expTime,
          );

          await this.setMemCache(tokenStore);

          let resultSet = await this.readMemCache();

          if (resultSet && resultSet.getToken() != '') {
            resp.tokenSave = true;

            resp.dateExpire = resultSet.getExpireDt();

            this.logger.log('Token get ' + resultSet.getToken());
          } else {
            resp.tokenSave = false;
          }
        } else {
          resp.tokenSave = false;
        }
      } else {
        resp.tokenSave = false;
      }

      return resp;
    } catch (error) {
      this.logger.log(JSON.stringify(error));
      resp.tokenSave = false;
      return resp;
    }
  }

  async storeTemplate(template: any, alias: string) {
    return new Promise(async (resolve) => {
      try {
        let data = JSON.stringify(template);
        console.log(data);

        this.logger.log('pathTemplateJson ' + pathTemplateJson);

        fs.writeFileSync(pathTemplateJson + alias + '.json', data);
        this.logger.log('Store Template ok');
        return resolve('ok');
      } catch (error) {
        this.logger.log('Store Template Error');
        this.logger.log(error);
        resolve(error);
      }
    }).catch((error) => {
      this.logger.log(error);
    });
  }

  async readTemplate(alias: string) {
    let structTemplate = new FptTemplateContract();

    return new Promise(async (resolve) => {
      try {
        let pathJson = pathTemplateJson + alias + '.json';

        if (fs.existsSync(pathJson)) {
          this.logger.log('pathJson Template ' + alias + ' ok ');

          await fs.readFile(pathJson, (err: any, data: any) => {
            let dataR = JSON.parse(data);
            if (
              dataR &&
              dataR.hasOwnProperty('templateId') &&
              dataR.hasOwnProperty('alias')
            ) {
              structTemplate.templateId = dataR.templateId;
              structTemplate.alias = dataR.alias;
              structTemplate.syncType = dataR.syncType;
              structTemplate.datas = dataR.datas;

              resolve(structTemplate);
            }
          });
        } else {
          resolve(structTemplate);
        }
      } catch (error) {
        this.logger.log('Load Store Template ' + alias + ' Error');
        this.logger.log(error);
        resolve(structTemplate);
      }
    }).catch((error) => {
      this.logger.log('Load Store Template ' + alias + ' Error');
      this.logger.log(error);
      return structTemplate;
    });
  }

  async callPostCancel(dataPost: any): Promise<any> {
    this.logger.log('Call cancel econtract API');
    this.logger.log(JSON.stringify(dataPost));

    if (_.isEmpty(dataPost)) {
      return {
        flagCancelSuccess: false,
      };
    }

    let { keyLink, envID } = dataPost;

    return this.callCancel(keyLink, envID);
  }

  async callCancel(keyLink: string, envID: string) {
    let tokenCache = await this.readMemCache();
    let tokenFptSt = '';
    let resData = {
      flagCancelSuccess: false,
      reasonFail: '',
    };

    const urlCallCancel =
      this.configService.get<string>('URL_CANCEL_KEYLINK') || '';

    this.logger.log('urlCallCancel ' + urlCallCancel);

    this.logger.log('keyLink ' + keyLink);
    this.logger.log('envID ' + envID);

    if (!keyLink || !envID) {
      this.logger.log('Input error !');
      return resData;
    }

    try {
      let flagExpire = tokenCache.checkExpire();

      if (flagExpire) {
        await this.getToken();
        tokenCache = await this.readMemCache();
      }

      tokenFptSt = tokenCache.getToken();

      this.logger.log('Token get ' + tokenFptSt);

      const configCallCancel = {
        method: 'post',
        maxBodyLength: Infinity,
        url: urlCallCancel,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + tokenFptSt,
          'Accept-Encoding': 'gzip, zlibgzip, deflate, compress, br',
        },
        data: {
          attrs: {},
          id: '',
          lookup: '',
          payload: '',
          body: {
            type: 'sync',
            actList: [
              {
                refId: keyLink,
                envelopeId: envID,
                reason: 'Hủy hợp đồng',
              },
            ],
          },
          refId: keyLink,
          selector: 'flow_processing_shinhan_cancel_contract',
        },
      };

      axiosRetry(axios, {
        retries: 3, // number of retries
        retryDelay: (retryCount) => {
          console.log(
            `Retry attempt call API Econtract cancel : ${retryCount}`,
          );
          return retryCount * 2000; // time interval between retries
        },
        retryCondition: axiosRetry.isRetryableError,
      });

      const res = await axios(configCallCancel);

      if (res && res.data) {
        this.logger.log(JSON.stringify(res.data));

        let responseData = res.data;
        if (responseData && responseData.hasOwnProperty('response')) {
          let { response } = responseData;

          if (response.hasOwnProperty('detail')) {
            let { detail } = response;

            if (Array.isArray(detail)) {
              let { status } = detail[0];

              this.logger.log(
                'keylink [' +
                  keyLink +
                  '] envID [' +
                  envID +
                  '] status >>>' +
                  status,
              );

              if (status == 'ok') {
                resData.flagCancelSuccess = true;
                return resData;
              } else {
                resData.reasonFail = detail[0];
              }
            }
          }
        }
      }
      return resData;
    } catch (error) {
      resData.flagCancelSuccess = false;
      this.logger.log(JSON.stringify(error));
      resData.reasonFail = 'Internal error code please check log';

      return resData;
    }
  }

  async getTemplate(alias: string) {
    let templateFpt = new FptTemplateContract();
    let tokenCache = await this.readMemCache();
    let tokenFptSt = '';
    const urlGetTemplate =
      this.configService.get<string>('URL_GET_TEMPLATE') || '';

    this.logger.log('urlGetTemplate ' + urlGetTemplate);

    try {
      let flagExpire = tokenCache.checkExpire();

      if (flagExpire) {
        await this.getToken();
        tokenCache = await this.readMemCache();
      }

      tokenFptSt = tokenCache.getToken();

      this.logger.log('Token get ' + tokenFptSt);

      const configCallGetTemplate = {
        method: 'get',
        maxBodyLength: Infinity,
        url: urlGetTemplate + alias,
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + tokenFptSt,
          'Accept-Encoding': 'gzip, zlibgzip, deflate, compress, br',
        },
      };

      axiosRetry(axios, {
        retries: 3, // number of retries
        retryDelay: (retryCount) => {
          console.log(
            `Retry attempt call API Econtract get template: ${retryCount}`,
          );
          return retryCount * 2000; // time interval between retries
        },
        retryCondition: axiosRetry.isRetryableError,
      });

      const res = await axios(configCallGetTemplate);

      if (res && res.data) {
        let responseData = res.data;
        if (responseData && responseData.hasOwnProperty('templateId')) {
          templateFpt = responseData;
        }
      }

      return templateFpt;
    } catch (error) {
      this.logger.log(JSON.stringify(error));
      return templateFpt;
    }
  }

  async splitAccountNo(splitAccountNo: string) {
    const arrList = splitAccountNo.split('');
    let accountNumberSplit = new AccountNumberSplit();

    let i = 0;

    arrList.forEach((c) => {
      switch (i) {
        case 4:
          accountNumberSplit.hd1 = c;
          break;
        case 5:
          accountNumberSplit.hd2 = c;
          break;
        case 6:
          accountNumberSplit.hd3 = c;
          break;
        case 7:
          accountNumberSplit.hd4 = c;
          break;
        case 8:
          accountNumberSplit.hd5 = c;
          break;
        case 9:
          accountNumberSplit.hd6 = c;
          break;
        default:
          break;
      }

      i++;

      return accountNumberSplit;
    });
  }

  async fillAndSendEcontract(dataFill: any, alias: string) {
    try {
      let fptTemplate = await this.readTemplate(alias);

      let fillTemplate = new FptTemplateGen();

      let fileNameFrontNation = '';
      let fileNameBackNation = '';

      let base64fileNameFrontNation = '';
      let base64fileNameBackNation = '';

      let issueDate = '';
      let issuePlace = '';
      let birthDate = '';
      let fullName = '';
      let mobiPhone = '';
      let homePhone = '';

      let currentAddress = '';
      let contactAddress = '';
      let fax = '';

      let sex = '';
      let margin = '';
      let accountNumber = '';

      //mục tiêu đầu tư
      let inv_purpose = '';
      //Thu nhập hàng năm
      let year_revenue = '';
      //Mức độ chấp nhận rủi ro
      let risky_rate = '';
      //Kinh nghiệm đầu tư
      let inv_experience = '';
      //Kiến thức đầu tư
      let inv_knowledge = '';
      //Fatca type
      let fatcaType = '';
      //Số tk SSTA
      let os_ssta_bank_number = '';
      //Tên ngân hàng SSTA
      let os_ssta_bank_nm = '';
      //os_cust_hold khách hàng  nắm giữ chức danh quản lý hoặc cổ đông lớn ở công ty đại chúng: yn
      let os_cust_hold = '';
      //os_related_person người có liên quan của khách hàng là người nội bộ của công ty dai chúng/quỹ đại chúng: yn
      let os_related_person = '';
      //Tên chủ tài khoản thanh toán
      let os_bank_act_nm = '';
      //STK ngân hàng thanh toán
      let os_bank_act_no = '';
      //Chi nhánh ngân hàng thanh toán
      let os_bank_nm = '';
      //tài khoản chứng khoán ở công ty khác có hay không
      let os_act_no_other_yn = '';
      //Số tài khoản chứng khoán ở công ty khác
      let os_act_no_other_number = '';
      //Tên tài khoản chứng khoán ở công ty khác
      let os_act_no_other_name = '';
      let email = '';
      let fullNameUperCase = '';
      //Nghề nghiệp
      let career = '';
      //Chức vụ
      let position = '';
      //Mã số thuế
      let tax = '';
      // DateTime sDate = DateTime.Now;

      // String signDate = sDate.ToString("dd");
      // String signMonth = sDate.ToString("MM");
      // String signYear = sDate.ToString("yyyy");

      let int_per_stk = '';
      let rel_per_stk = '';
      let lg_shr_stk = '';
      let lg_shr_hold = '';

      return true;
    } catch (error) {
      this.logger.log(JSON.stringify(error));

      return false;
    }
  }

  async getAllTemplateEcontract() {
    try {
      let alias = 'HDMTK04';
      let templateResonse = await this.getTemplate(alias);
      let store = await this.storeTemplate(templateResonse, alias);

      templateResonse = await this.getTemplate(alias);
      alias = 'MARGIN';
      await this.storeTemplate(templateResonse, alias);

      templateResonse = await this.getTemplate(alias);
      alias = 'HDMTKBS01';
      await this.storeTemplate(templateResonse, alias);

      return {
        flagRunAll: true,
      };
    } catch (error) {
      this.logger.log(JSON.stringify(error));
      return {
        flagRunAll: false,
      };
    }
  }
}
