export class SSVMwInfo {
  Socket: any;
  SocketId: string; // ALtMW.NodejS: + số tự tăng
  SSVMWHost: string; // Host MW
  LastReplyTime: string;
  SendPingTime: string;
  ServerTime: string;
  IsConnect: boolean;
  TotalReq: number;
}

export interface MessageCallback<T> {
  (event: string, data: T): void;
}
