import { Module } from '@nestjs/common';
import { ZeroMqService } from './zeromq.service';

@Module({
  providers: [ZeroMqService],
  exports: [ZeroMqService],
})
export class ZeroMqModule {}
