import { HttpException, HttpStatus, Injectable, Logger } from "@nestjs/common";
import { AddBadWord, BadWord } from "../dto/SendInfo.dto";
import { ConfigService } from "@nestjs/config";
import BadWordsNext from "bad-words-next";

import vntk from "vntk";
import { badWords } from "../lib/blackList";
import * as fs from "fs";
import { IBadWordService } from "./i.bad-words.service";
@Injectable()
export class BadWordService implements IBadWordService {
  constructor(private configService: ConfigService) {}
  private readonly logger = new Logger(BadWordService.name);

  async checkBadWord(data: BadWord): Promise<any> {
    let response = {};

    if (data.sentence === "") {
      response = {
        data: {
          isBadWord: false,
          contentReplace: "",
        },
        status: "SUCCESS",
      };

      return response;
    }

    if (!data?.sentence || typeof data?.sentence !== "string") {
      response = {
        data: {},
        message: "[ERR] Vui lòng nhập chuỗi",
        status: "ERROR",
      };
      throw new HttpException(response, HttpStatus.BAD_REQUEST);
    }

    function escapeRegExp(string: string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& means the whole matched string
    }

    function replaceAll(str: string, find: string, replace: string) {
      return str.replace(new RegExp(escapeRegExp(find), "g"), replace);
    }

    // function removeVietnameseTones(str: string) {
    //   str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
    //   str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
    //   str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
    //   str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
    //   str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
    //   str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
    //   str = str.replace(/đ/g, 'd');
    //   str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
    //   str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
    //   str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
    //   str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
    //   str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
    //   str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
    //   str = str.replace(/Đ/g, 'D');
    //   // Some system encode vietnamese combining accent as individual utf-8 characters
    //   // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
    //   str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ''); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
    //   str = str.replace(/\u02C6|\u0306|\u031B/g, ''); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
    //   // Remove extra spaces
    //   // Bỏ các khoảng trắng liền nhau
    //   str = str.replace(/ + /g, ' ');
    //   str = str.trim();
    //   // Remove punctuations
    //   // Bỏ dấu câu, kí tự đặc biệt
    //   str = str.replace(
    //     /!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g,
    //     ' ',
    //   );
    //   return str;
    // }

    const tokenizer = vntk.wordTokenizer();
    const util = vntk.util();

    const dataBreak = tokenizer.tag(data.sentence);
    let newPhrase = data.sentence.toString().trim();

    const blackListVi = JSON.parse(fs.readFileSync("lang/vi.json", "utf-8"));

    const wordArrViBlacklist = blackListVi.words;
    let flagCheck = false;

    const blackListEn = JSON.parse(fs.readFileSync("lang/en.json", "utf-8"));
    const blackListKo = JSON.parse(fs.readFileSync("lang/ko.json", "utf-8"));

    const badWordsList = new BadWordsNext({ data: blackListEn });
    badWordsList.add(blackListKo);

    const listBadWord = [];

    flagCheck = badWordsList.check(newPhrase);
    newPhrase = badWordsList.filter(newPhrase, (badword) =>
      listBadWord.push(badword)
    );

    if (badWords(newPhrase, { validate: true })) {
      flagCheck = true;
      newPhrase = badWords(newPhrase, { replacement: "*" }).toString();
    }

    if (Array.isArray(dataBreak)) {
      dataBreak.forEach((element: any) => {
        if (wordArrViBlacklist.includes(element.toLowerCase().trim())) {
          listBadWord.push(element);
          flagCheck = true;
          newPhrase = replaceAll(newPhrase, element.trim(), "***");
        }
      });
    }

    response = {
      data: {
        isBadWord: flagCheck,
        contentReplace: util.clean_html(newPhrase),
        badWordsList: listBadWord,
      },
      status: "SUCCESS",
    };

    return response;
  }

  async addBadWord(data: AddBadWord): Promise<any> {
    let response = {};
    let srcFile = "lang/vi.json";

    switch (data.lang) {
      case "en":
        srcFile = "lang/en.json";
        break;
      case "ko":
        srcFile = "lang/ko.json";
        break;
      default:
        break;
    }

    if (data.words?.trim() === "") {
      response = {
        message: "[ERR] Không tìm thấy từ cần thêm",
        status: "ERROR",
      };

      throw new HttpException(response, HttpStatus.BAD_REQUEST);
    }

    const existingData: { words: string[]; phrase: string[] } = JSON.parse(
      fs.readFileSync(srcFile, "utf-8")
    );

    if (
      existingData.words.includes(data.words) ||
      existingData.phrase.includes(data.words)
    ) {
      response = {
        message: "[ERR] Đã tồn tại trong từ điển",
        status: "ERROR",
      };
      throw new HttpException(response, HttpStatus.CONFLICT);
    }

    if (data?.isPhrase) {
      existingData?.phrase?.push(data.words);
    } else {
      existingData?.words?.push(data.words);
    }

    fs.writeFileSync(srcFile, JSON.stringify(existingData, null, 2));

    response = {
      message: "[SUC] Thêm thành công",
      status: "SUCCESS",
    };

    return response;
  }
}
