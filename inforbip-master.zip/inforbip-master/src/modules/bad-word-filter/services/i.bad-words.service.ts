import { AddBadWord, BadWord } from '../dto/SendInfo.dto';

export interface IBadWordService {
  index?(): Promise<any>;
  checkBadWord(data: BadWord): Promise<any>;
  addBadWord(data: AddBadWord): Promise<any>;
}
