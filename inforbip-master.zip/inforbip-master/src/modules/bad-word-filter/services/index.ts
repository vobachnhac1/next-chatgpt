export * from './badwords.service';
