import {
  Body,
  Controller,
  HttpCode,
  Post,
  ValidationPipe,
} from '@nestjs/common';
import { BadWordService } from '../services/badwords.service';
import { AddBadWord, BadWord } from '../dto/SendInfo.dto';

@Controller('badword')
export class ApiCmsController {
  constructor(private readonly appService: BadWordService) {}

  // private readonly logger = new Logger(ApiCmsController.name);

  @Post('check')
  @HttpCode(200)
  async checkBadWord(@Body(ValidationPipe) data: BadWord): Promise<any> {
    return await this.appService.checkBadWord(data);
  }

  @Post('add')
  @HttpCode(200)
  async addBadWord(@Body() data: AddBadWord): Promise<any> {
    return this.appService.addBadWord(data);
  }
}
