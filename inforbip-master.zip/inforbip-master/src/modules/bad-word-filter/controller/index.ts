export * from './filter-bad-words.controller';
