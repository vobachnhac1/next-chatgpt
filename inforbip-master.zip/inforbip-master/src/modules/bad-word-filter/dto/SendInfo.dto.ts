import { ApiProperty } from '@nestjs/swagger';

export class BadWord {
  @ApiProperty({ description: 'Câu' })
  sentence: string;
}

export class AddBadWord {
  @ApiProperty({ description: 'Từ xấu' })
  words: string;
  @ApiProperty({ description: 'Câu/ Cụm từ', default: false })
  isPhrase: boolean;
  @ApiProperty({ description: 'Ngôn ngữ', default: 'vi' })
  lang: string;
}
