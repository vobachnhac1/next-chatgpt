import { Module } from '@nestjs/common';
import { SocketGateway } from './socket.gateway';
import { ZeroMqModule } from '../zeromq/zeromq.module';

@Module({
  imports: [ZeroMqModule],
  providers: [SocketGateway],
})
export class SocketModule {}
