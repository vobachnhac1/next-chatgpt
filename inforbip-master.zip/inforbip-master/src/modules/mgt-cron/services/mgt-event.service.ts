import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ServerRequestApi } from 'src/modules/api-infobip/dto/ServerAPI.dto';
import { ServerAPIFosService } from 'src/modules/api-infobip/services';
import { GetIPAddress } from 'src/utils/global.service';
const moment = require("moment");
const chalk = require("chalk");

@Injectable()
export class MgtCronEventService {
  constructor(
    private configService: ConfigService,
    private server: ServerAPIFosService,
  ) {}
  private readonly logger = new Logger(MgtCronEventService.name);

  async getHOSTest(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqCommon02';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqCommon02_Get_Time';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();

    // Thêm thông số không cần thiết nhưng phải khai báo
    return this.server.callSocketHos(svApiFmt);
  }

  async getHosAcc(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqAccount';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqAccount_Common_1';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 180;
    svApiFmt.MWLoginID = 'BOS';

    // Thêm thông số không cần thiết nhưng phải khai báo
    return await this.server.callSocketHos(svApiFmt);
  }


  async getdataInsertQueueInfobip(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqAccount';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqAccount_OTT_GetListData';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 180;
    svApiFmt.MWLoginID = 'BOS';


    this.logger.log(
      chalk.green(
        moment().format("YYYY_MM_DD HH:MM:SS") +
        " <<********************************************Start getdataInsertQueueInfobip  ALTqAccount_OTT_GetListData *>> " + JSON.stringify(svApiFmt.InVal)+"<<<*********>>"
      )
    );


    console.log('Service getDataNeedCreateQueueInforBip call direct');

    // Thêm thông số không cần thiết nhưng phải khai báo
    return await this.server.callSocketHos(svApiFmt);
  }

  async insertToQueueInfobip(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTxAccount01';
    svApiFmt.Operation = 'I';
    svApiFmt.ServiceName = 'ALTxAccount01_OTT_Insert_Queue';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 180;
    svApiFmt.MWLoginID = 'BOS';

    console.log('Service getDataNeedCreateQueueInforBip call direct');

    // Thêm thông số không cần thiết nhưng phải khai báo
    return await this.server.callSocketHos(svApiFmt);
  }

  async getQueueData(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTqAccount';
    svApiFmt.Operation = 'Q';
    svApiFmt.ServiceName = 'ALTqAccount_OTT_GetListData';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 180;
    svApiFmt.MWLoginID = 'BOS';

    this.logger.log(
      chalk.green(
        moment().format("YYYY_MM_DD HH:MM:SS") +
        " <<********************************************Start getDataNeedCreateQueueInforBip  ALTqAccount_OTT_GetListData *>> " + JSON.stringify(svApiFmt.InVal)+"<<<*********>>"
      )
    );


    console.log('Service getDataNeedCreateQueueInforBip call direct');

    // Thêm thông số không cần thiết nhưng phải khai báo
    return await this.server.callSocketHos(svApiFmt);
  }

  async updateQueueData(data: ServerRequestApi): Promise<any> {
    this.logger.log(JSON.stringify(data));
    let svApiFmt = new ServerRequestApi();
    svApiFmt.ClientSeq = new Date().getTime();
    svApiFmt.Lang = 'VI';
    svApiFmt.WorkerName = 'ALTxAccount01';
    svApiFmt.Operation = 'U';
    svApiFmt.ServiceName = 'ALTxAccount01_OTT_Update_Queue';
    svApiFmt.InVal = data.InVal;
    svApiFmt.TotInVal = data.TotInVal;
    svApiFmt.IPPrivate = GetIPAddress();
    svApiFmt.IPPublic = data.IPPublic ? data.IPPublic : GetIPAddress();
    svApiFmt.TimeOut = 180;
    svApiFmt.MWLoginID = 'BOS';

    console.log('Service getDataNeedCreateQueueInforBip call direct');

    // Thêm thông số không cần thiết nhưng phải khai báo
    return await this.server.callSocketHos(svApiFmt);
  }
}
