import {
  Injectable,
  Logger,
  OnModuleInit,
  OnModuleDestroy
} from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { Cron, SchedulerRegistry, CronExpression } from "@nestjs/schedule";
import { CronJob } from "cron";
import { ServerRequestApi } from "src/modules/api-infobip/dto/ServerAPI.dto";
import { MgtCronEventService } from "./mgt-event.service";
import { GlobalService } from "../../../utils/global.service";
import { GlobalSearch } from "../../../utils/global.search";

const myCache = require("../../../utils/cache");

const moment = require("moment");
const chalk = require("chalk");
import { LowdbService } from "src/utils";
import { ApiInfoBipService } from "src/modules/api-infobip/services";
import {
  ServerToZalo,
  InfoDestinationMessZalo
} from "src/modules/api-infobip/dto/SendInfo.dto";
import { error } from "winston";

const retry = require("promise-retry");
const _ = require("lodash");

enum TableDefault {
  accounts = "accounts",
}

@Injectable()
export class MgtCronService implements OnModuleInit, OnModuleDestroy {
  constructor(
    private configService: ConfigService,
    private cronEvent: MgtCronEventService,
    private lowdbService: LowdbService,
    private schedulerRegistry: SchedulerRegistry,
    private appService: ApiInfoBipService
  ) {
  }

  private readonly logger = new Logger(MgtCronService.name);

  onModuleInit() {

    this.restartSavedCronTasks();

    const TYPE_CRON =
      this.configService.get<string>("typeR") || "INFOBIP_MOVE_TABLE";

    if (TYPE_CRON == "INFORBIP_QUEUE") {
      //R5881: Cron Insert
      const TIME_CRON_INSERT_INFORBIP =
        this.configService.get<string>("TIME_CRON_INSERT_INFORBIP") ||
        "*/10 * * * * *";

      this.logger.log(
        "TIME_CRON_INSERT_INFORBIP >> " + TIME_CRON_INSERT_INFORBIP
      );

      const jobInsert = new CronJob(TIME_CRON_INSERT_INFORBIP, () => {
        // What you want to do here
        this.logger.log(
          moment().format("YYYY_MM_DD HH:MM:SS") +
          " <<*TIME_CRON_INSERT_INFORBIP start*>> "
        );
        GlobalService.checkInsertQueue = true;

        this.handleCronJobCreateQueueInforBip();
      });

      this.schedulerRegistry.addCronJob(
        "CRON_INFORBIP_CREATE_QUEUE",
        jobInsert
      );

      jobInsert.start();
    }

    if (TYPE_CRON == "INFORBIP_SEND") {
      //R5881: Cron Update
      const TIME_CRON_UPDATE_INFORBIP =
        this.configService.get<string>("TIME_CRON_UPDATE_INFORBIP") ||
        "*/20 * * * * *";

      const jobUpdate = new CronJob(TIME_CRON_UPDATE_INFORBIP, () => {
        this.logger.log(
          moment().format("YYYY_MM_DD HH:MM:SS") +
          " <<*TIME_CRON_UPDATE_INFORBIP start*>>"
        );

        GlobalService.checkUpdateQueue = true;

        this.processSendInfobip();
      });

      this.schedulerRegistry.addCronJob(
        "CRON_INFORBIP_UPDATE_QUEUE",
        jobUpdate
      );

      jobUpdate.start();
    }

    if (TYPE_CRON == "INFOBIP_SEND_DAILY") {
      //R6184: Cron Send Daily
      const TIME_CRON_INFOBIP_SEND_DAILY =
        this.configService.get<string>("TIME_CRON_INFOBIP_SEND_DAILY") ||
        "*/20 * * * * *";

      const jobUpdate = new CronJob(TIME_CRON_INFOBIP_SEND_DAILY, () => {
        this.logger.log(
          moment().format("YYYY_MM_DD HH:MM:SS") +
          " <<*TIME_CRON_INFOBIP_SEND_DAILY start*>>"
        );

        GlobalService.checkRunSendDailyInfobip = true;

        this.handleSendInfobipDaily();
      });

      this.schedulerRegistry.addCronJob(
        "TIME_CRON_INFOBIP_SEND_DAILY",
        jobUpdate
      );

      jobUpdate.start();
    }

    if (TYPE_CRON == "INFOBIP_MOVE_TABLE") {
      //Move table call
      const INFOBIP_MOVE_TABLE =
        this.configService.get<string>("TIME_CRON_INFOBIP_MOVE_TABLE") ||
        "*/20 * * * * *";

      this.logger.log('INFOBIP_MOVE_TABLE CRON :'+INFOBIP_MOVE_TABLE);

      const jobUpdate = new CronJob(INFOBIP_MOVE_TABLE, () => {
        this.logger.log(
          moment().format("YYYY_MM_DD HH:MM:SS") +
          " <<*INFOBIP_MOVE_TABLE start*>>"
        );


        this.moveHistoryZalo();
      });

      this.schedulerRegistry.addCronJob(
        "INFOBIP_MOVE_TABLE",
        jobUpdate
      );

      jobUpdate.start();
    }

  }

  onModuleDestroy() {
    this.logger.log(
      moment().format("YYYY_MM_DD HH:MM:SS") + " cronjob destroy"
    );
  }

  private async restartSavedCronTasks(): Promise<void> {
    // get date from DB and start all relevant tasks

    this.logger.log(moment().format("YYYY_MM_DD HH:MM:SS") + " cronjob start ");
  }

  @Cron(CronExpression.EVERY_DAY_AT_3AM)
  private async clearOldFileLog(): Promise<void> {
    this.logger.log(
      moment().format("YYYY_MM_DD HH:MM:SS") + " clearOldFileLog start "
    );

    const path = require("path");

    const fs = require("fs").promises; // Use promises for async/await

    async function removeOldFiles(directory, thresholdInMilliseconds) {
      const files = await fs.readdir(directory);

      for (const file of files) {
        const filePath = path.join(directory, file); // Use path.join for safe path construction
        const stats = await fs.stat(filePath);
        const now = Date.now();

        if (now - stats.mtimeMs > thresholdInMilliseconds) {
          await fs.unlink(filePath);
          this.logger.log(`Deleted old file: ${filePath}`);
        }
      }
    }

    const directory = "logs/";
    const oneDayInMilliseconds = 5 * (24 * 60 * 60 * 1000); //5 day clear
    removeOldFiles(directory, oneDayInMilliseconds); // Remove files older than one day
  }

  // @Cron(CronExpression.EVERY_SECOND) // Runs every 5 second
  // async handleCron() {
  //   if(!GlobalService.globalCheckCron) {
  //       GlobalService.globalCheckCron = 0;
  //       GlobalService.flagSuccessConnect = true;
  //   }
  //
  //   GlobalService.globalCheckCron = GlobalService.globalCheckCron + 1;
  //
  //   this.logger.log(chalk.blue("GlobalService.globalCheckCron "+GlobalService.globalCheckCron));
  //   this.logger.log(chalk.yellow(" GlobalService.flagSuccessConnect "+ GlobalService.flagSuccessConnect));
  //
  //
  //   try {
  //
  //     const queue = require('fastq').promise(worker, 3);
  //
  //
  //     async function worker (arg) {
  //       return new Promise((resolve, reject) => {
  //         setTimeout(() => {
  //           this.logger.log("Delayed for solve "+arg+" second.");
  //           resolve(arg );
  //         }, 1000);
  //       })
  //     }
  //
  //     async function run (numberInput) {
  //       return new Promise(async (resolve, reject) => {
  //         const result = await queue.push(numberInput);
  //         this.logger.log('the result is solve ', result);
  //         resolve(result);
  //       });
  //
  //     }
  //
  //     await run(1);
  //     await run(2);
  //     await run(3);
  //
  //
  //
  //   } catch (error) {
  //       this.logger.log(error);
  //   }
  // }

  @Cron(CronExpression.EVERY_30_SECONDS)
  async handleSyncAcc() {
    const TYPE_CRON = this.configService.get<string>("typeR") || "ACC_X";

    console.log("TYPE_CRON", TYPE_CRON);

    if (TYPE_CRON == "ACC") {
      this.logger.log(chalk.blue("<<Start sync Account begin>>"));

      try {
        let data = new ServerRequestApi();
        data.InVal = ["wait_account"];
        data.TotInVal = 1;

        let responseResult = await this.cronEvent.getHosAcc(data);

        if (responseResult) {
          let { data } = responseResult;

          // this.logger.log(chalk.cyan('<<*Start data return begin*>>'));
          // this.logger.log('responseResultData ', data);
          // this.logger.log(chalk.cyan('<<*Start data return end*>>'));

          const setDbR = await this.lowdbService.addlist(
            data,
            TableDefault.accounts,
            true
          );
          //this.logger.log('setDbResult   ', setDbR);

          let successFlag = myCache.set("accountCache", data, 3000);

          this.logger.log("successFlag cache  =>>>>> ", successFlag);
          GlobalSearch.globalAccArray = data;
          await GlobalSearch.indexAcc();
        }
      } catch (error) {
        this.logger.log(error);
      }

      this.logger.log(chalk.blue("<<Start sync Account end>>"));
    }
  }

  //Create Queue Zalo
  async handleCronJobCreateQueueInforBip() {
    const TYPE_CRON =
      this.configService.get<string>("typeR") || "INFORBIP_QUEUE_X";

    if (TYPE_CRON == "INFORBIP_QUEUE") {
      if (GlobalService.checkInsertQueue) {
        this.logger.log(
          chalk.blue(
            moment().format("YYYY_MM_DD HH:MM:SS") +
            " <<*Start cronjob get list data need to be inserted into InforBip begin*>>"
          )
        );

        try {
          const fromDT =
            this.configService.get<string>("FROM_DT_START") || "20230810";

          const dataRequest = new ServerRequestApi();
          dataRequest.TotInVal = 3;
          dataRequest.InVal = ["data_availible", "date", fromDT];

          const myAsyncFunction = async () => {
            this.logger.log(
              chalk.cyan(
                "<<*Begin get return data insert into queue Infobip*>>"
              )
            );
            const responseResult =
              await this.cronEvent.getdataInsertQueueInfobip(dataRequest);
            let dataMap = [];
            this.logger.log(
              "<<*Response Result*>> -> " + JSON.stringify(responseResult)
            );

            if (responseResult) {
              const { data } = responseResult;
              dataMap = data;
              this.logger.log(
                chalk.cyan(
                  "<<*End get return data insert into queue Infobip*>>"
                )
              );
            } else {
              return `<<*Fail to get data insert into queue*>>`;
            }

            if (dataMap.length > 0) {
              this.logger.log(
                chalk.cyan(
                  "<<*Begin insert result queue data into database*>>"
                )
              );

              dataMap.forEach(async (data) => {
                if (data) {
                  dataRequest.TotInVal = 3;
                  dataRequest.InVal = [data.c0, data.c2, data.c4];
                  GlobalService.checkInsertQueue = false;

                  this.logger.log(
                    "<<*Data queue insert to database*>> -> " +
                    dataRequest.InVal
                  );

                  await this.cronEvent.insertToQueueInfobip(dataRequest);

                  this.logger.log(
                    chalk.blue(
                      "<<*Insert queue user " + data.c0 + " complete*>>"
                    )
                  );
                }
              });
              this.logger.log(
                chalk.cyan("<<*End insert result queue data into database*>>")
              );

              return `Success`;
            } else {
              this.logger.log(
                chalk.red("<<*Data get from queue for Infobip null*>>")
              );

              return `No data get from Queue`;
            }
            return `Success`;
          };

          retry(async () => await myAsyncFunction(), {
            retries: 2, // Số lần retry tối đa
            minTimeout: 4000, // Thời gian chờ tối thiểu giữa các lần retry (ms)
            maxTimeout: 8000, // Thời gian chờ tối đa giữa các lần retry (ms)
            onRetry: (retryCount, error) => {
              this.logger.log(`Retry count: ${retryCount}: ${error.message}`);
            }
          })
            .then((result) => {
              this.logger.log("Result: >>>>" + JSON.stringify(result));
              GlobalService.checkInsertQueue = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<Start cronjob get list data need to be inserted into InforBip end*>>"
                )
              );
            })
            .catch((error) => {
              this.logger.log("Error: >>>>" + error.message);
              GlobalService.checkInsertQueue = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<*Start cronjob get list data need to be inserted into InforBip end*>>"
                )
              );
            });
        } catch (error) {
          this.logger.log("Error catch : >>>>" + JSON.stringify(error));
        }
      } else {
        this.logger.log(
          chalk.red(
            moment().format("YYYY_MM_DD HH:MM:SS") +
            " <<*Cronjob cronjob get list data need to be inserted into InforBip busy waiting finish old queue*>>"
          )
        );
      }
    }
  }

  //Send Queue Zalo
  async processSendInfobip() {
    const TYPE_CRON =
      this.configService.get<string>("typeR") || "INFORBIP_SEND_X";

    if (TYPE_CRON == "INFORBIP_SEND") {
      if (GlobalService.checkUpdateQueue) {
        this.logger.log(
          chalk.blue(
            moment().format("YYYY_MM_DD HH:MM:SS") +
            " <<*Start cronjob get list data need update status InforBip begin*>>"
          )
        );

        try {
          const dataRequest = new ServerRequestApi();
          dataRequest.TotInVal = 2;
          dataRequest.InVal = ["data_queue", "all"];

          const myAsyncFunction = async () => {
            this.logger.log(
              chalk.cyan(
                "<<*Begin get return data update status queue into Infobip*>>"
              )
            );
            const responseResult = await this.cronEvent.getQueueData(
              dataRequest
            );
            let dataMap = [];

            if (responseResult) {
              const { data } = responseResult;
              this.logger.log(
                "<<*Response Result*>> -> " + JSON.stringify(data)
              );

              dataMap = data;

              this.logger.log(
                chalk.green(
                  "<<*End get return data update status queue into Infobip*>>"
                )
              );
            } else {
              this.logger.log(
                chalk.red("<<*Data get from queue for Infobip null*>>")
              );

              return `Fail to get data for update queue`;
            }

            if (dataMap.length > 0) {
              for (const data of dataMap) {
                const destinations: InfoDestinationMessZalo = {
                  to: data.c7,
                  messageId: data.c8
                };
                const list: InfoDestinationMessZalo[] = [];
                list.push(destinations);
                const serverZalo = new ServerToZalo();
                serverZalo.type = "TEMPLATE";
                serverZalo.templateName = data.c2;
                serverZalo.templateData = {
                  code: data.c3,
                  customer_name: data.c4,
                  date_time: moment(data.c0, "YYYYMMDD").format("DD/MM/YYYY")
                };
                serverZalo.destinations = list;
                serverZalo.urlWebhooks = data.c9;

                this.logger.log(
                  chalk.green("<<*Send data into Infobip Zalo begin*>>")
                );

                this.logger.log(
                  "<<*Input to send send Infobip Zalo*>>" +
                  JSON.stringify(serverZalo)
                );

                // R5881: For connection with infobip
                const sendMess = this.appService.sendMessZalo(serverZalo);

                sendMess.then(async (value) => {
                  const res = JSON.stringify(value);

                  this.logger.log("<<*Response result*>> => " + res);

                  this.logger.log(
                    chalk.green("<<*Send data into Infobip Zalo end *>>")
                  );

                  const resObject = JSON.parse(res);
                  const status = resObject.statusCode;

                  let sendType = "3";
                  if (status != 200) {
                    sendType = "4";
                  }

                  this.logger.log(
                    chalk.cyan(
                      "<<*Begin update data into database after sending Infobip*>>"
                    )
                  );

                  const dataInsertRequest = new ServerRequestApi();

                  dataInsertRequest.TotInVal = 8;
                  dataInsertRequest.InVal = [
                    "cron_job",
                    data.c0,
                    data.c1,
                    data.c10,
                    sendType,
                    data.c8,
                    data.c2,
                    data.c11
                  ];

                  this.logger.log(
                    "<<*Data params to update status queue*>> => " +
                    JSON.stringify(dataInsertRequest.InVal)
                  );

                  GlobalService.checkUpdateQueue = false;
                  await this.cronEvent.updateQueueData(dataInsertRequest);
                  this.logger.log(
                    chalk.cyan(
                      "<<*End update data into after sending Infobip*>>"
                    )
                  );
                });
              }
              return `Success`;
            } else {
              this.logger.log(
                chalk.red("<<*Data get from queue for Infobip null*>>")
              );

              return `No data get from Queue`;
            }
          };

          retry(async () => await myAsyncFunction(), {
            retries: 2, // Số lần retry tối đa
            minTimeout: 4000, // Thời gian chờ tối thiểu giữa các lần retry (ms)
            maxTimeout: 8000, // Thời gian chờ tối đa giữa các lần retry (ms)
            onRetry: (retryCount, error) => {
              this.logger.log(`Retry count: ${retryCount}: ${error.message}`);
            }
          })
            .then((result) => {
              this.logger.log("Result: >>>>" + JSON.stringify(result));
              GlobalService.checkUpdateQueue = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<Start cronjob get list data need update status InforBip end>>"
                )
              );
            })
            .catch((error) => {
              this.logger.log("Error: >>>>" + error.message);
              GlobalService.checkUpdateQueue = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<Start cronjob get list data need update status InforBip end>>"
                )
              );
            });
        } catch (error) {
          this.logger.log("Error catch : >>>>" + JSON.stringify(error));
        }
      } else {
        this.logger.log(
          chalk.red(
            moment().format("YYYY_MM_DD HH:MM:SS") +
            " <<Cronjob get list data need update InforBip busy waitting finish old queue>>"
          )
        );
      }
    }
  }

  //Send Queue Zalo often --R6184 improve infobi[
  async handleSendInfobipDaily() {
    const TYPE_CRON =
      this.configService.get<string>("typeR") || "INFOBIP_SEND_DAILY_X";

    this.logger.log("TYPE_CRON handleSendInfobipDaily " + TYPE_CRON);

    if (TYPE_CRON == "INFOBIP_SEND_DAILY") {
      if (GlobalService.checkRunSendDailyInfobip) {
        try {

          this.logger.log("Start call get from pro *C");

          const dataRequest = new ServerRequestApi();
          dataRequest.TotInVal = 1;
          dataRequest.InVal = ["data_bos_queue"];

          const myAsyncFunction = async () => {
            this.logger.log(
              chalk.cyan(
                "<<*Begin get return data send Infobip*>>"
              )
            );
            const responseResult =
              await this.cronEvent.getdataInsertQueueInfobip(dataRequest);
            let dataMap = [];
            this.logger.log(
              "<<*Response Result*>> -> " + JSON.stringify(responseResult)
            );

            if (responseResult) {
              const { data } = responseResult;
              dataMap = data;
              this.logger.log(
                chalk.cyan(
                  "<<*End get return data send Infobip*>>"
                )
              );
            } else {
              return `<<*Fail to get data send Infobip*>>`;
            }

            if (dataMap.length > 0) {
              this.logger.log(
                chalk.cyan(
                  "<<*Begin send InfoBip *>>"
                )
              );

              for (const data of dataMap) {
                const destinations: InfoDestinationMessZalo = {
                  to: data.c7,
                  messageId: data.c8
                };
                const list: InfoDestinationMessZalo[] = [];
                list.push(destinations);
                const serverZalo = new ServerToZalo();
                serverZalo.type = "TEMPLATE";
                serverZalo.templateName = data.c2;
                serverZalo.templateData = {
                  code: data.c3,
                  customer_name: data.c4,
                  date_time: moment(data.c0, "YYYYMMDD").format("DD/MM/YYYY"),
                  email:data.c5 ? data.c5: ' '
                };
                serverZalo.destinations = list;
                serverZalo.urlWebhooks = data.c9;

                this.logger.log(
                  chalk.green("<<*Send data into Infobip Zalo begin*>>")
                );

                this.logger.log(
                  "<<*Input to send send Infobip Zalo*>>" +
                  JSON.stringify(serverZalo)
                );

                // R5881: For connection with infobip
                const sendMess = this.appService.sendMessZalo(serverZalo);

                sendMess.then(async (value) => {
                  const res = JSON.stringify(value);

                  this.logger.log("<<*Response result*>> => " + res);

                  this.logger.log(
                    chalk.green("<<*Send data into Infobip Zalo end *>>")
                  );

                  const resObject = JSON.parse(res);
                  const status = resObject.statusCode;

                  let sendType = "3";
                  if (status != 200) {
                    sendType = "4";
                  }

                  this.logger.log(
                    chalk.cyan(
                      "<<*Begin update data into database after sending Infobip*>>"
                    )
                  );

                  const dataInsertRequest = new ServerRequestApi();

                  dataInsertRequest.InVal = [
                    "cron_job_bos",
                    data.c0,
                    data.c1,
                    data.c10,
                    sendType,
                    data.c8
                  ];

                  dataInsertRequest.TotInVal = dataInsertRequest.InVal.length;

                  this.logger.log(
                    "<<*Data params to update status queue*>> => " +
                    JSON.stringify(dataInsertRequest.InVal)
                  );

                  GlobalService.checkRunSendDailyInfobip = false;
                  await this.cronEvent.updateQueueData(dataInsertRequest);
                  this.logger.log(
                    chalk.cyan(
                      "<<*End update data into after sending Infobip*>>"
                    )
                  );
                });
              }

              this.logger.log(
                chalk.cyan("<<*End send InfoBip *>>")
              );

              return `Success`;
            } else {
              this.logger.log(
                chalk.red("<<*Data get from queue for Infobip null*>>")
              );

              return `No data get from Queue`;
            }
            return `Success`;
          };


          retry(async () => await myAsyncFunction(), {
            retries: 2, // Số lần retry tối đa
            minTimeout: 4000, // Thời gian chờ tối thiểu giữa các lần retry (ms)
            maxTimeout: 8000, // Thời gian chờ tối đa giữa các lần retry (ms)
            onRetry: (retryCount, error) => {
              this.logger.log(`Retry count: ${retryCount}: ${error.message}`);
            }
          })
            .then((result) => {
              this.logger.log("Result: >>>>" + JSON.stringify(result));
              GlobalService.checkRunSendDailyInfobip = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<Start cronjob get list data need update status InforBip end>>"
                )
              );
            })
            .catch((error) => {
              this.logger.log("Error: >>>>" + error.message);
              GlobalService.checkRunSendDailyInfobip = true;
              this.logger.log(
                chalk.blue(
                  moment().format("YYYY_MM_DD HH:MM:SS") +
                  " <<Start cronjob get list data need update status InforBip end>>"
                )
              );
            });
        } catch (error) {
          this.logger.log("Error catch : >>>>" + JSON.stringify(error));
        }


      } else {
        this.logger.log(
          chalk.red(
            moment().format("YYYY_MM_DD HH:MM:SS") +
            " <<*Cronjob cronjob get list data INFORBIP_SEND_DAILY busy waiting finish old queue*>>"
          )
        );
      }

    }
  }

  //Move old table
  async  moveHistoryZalo() {
    const TYPE_CRON =
      this.configService.get<string>("typeR") || "INFOBIP_MOVE_TABLE";

    this.logger.log("TYPE_CRON moveHistoryZalo " + TYPE_CRON);

    if(GlobalService.checkMoveTableInfobip === undefined)
    {
      GlobalService.checkMoveTableInfobip = true;
    }

    if (TYPE_CRON == "INFOBIP_MOVE_TABLE" &&  GlobalService.checkMoveTableInfobip)  {
      this.logger.log(
        chalk.cyan(
          "<<*Begin move history Infobip*>>"
        )
      );

      var promiseRetry = require('promise-retry');


      const myAsyncFunction = async () => {
        return new Promise(async (resolve, reject) : Promise<any> => {


            const dataInsertRequest = new ServerRequestApi();

            dataInsertRequest.InVal = [
              "cron_end_date",

            ];

            dataInsertRequest.TotInVal = dataInsertRequest.InVal.length;

            this.logger.log(
              "<<*Data params to call ALTx *>> => " +
              JSON.stringify(dataInsertRequest.InVal)
            );

            GlobalService.checkMoveTableInfobip = false;

            const responseResult = await this.cronEvent.updateQueueData(dataInsertRequest);


            if (responseResult) {

              console.log(JSON.stringify(responseResult));

              let { success } = responseResult;

              if (!success) {

                 reject('ALTx not work !')
              }

            } else {
              reject('ALTx not work !')
            }


           resolve('OK');
        })

      };

      const thisClassLog = this.logger;


      promiseRetry(
        async  function (retry, number) {
          thisClassLog.log(
            chalk.blue(
              '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'+
              moment().format("YYYY_MM_DD HH:MM:SS") + '>>> INFOBIP_MOVE_TABLE Count number call : ' +number
            )
          );

              return  myAsyncFunction().catch(retry);

        }
        , {
        retries: 3, // Số lần retry tối đa
        minTimeout: 1000, // Thời gian chờ tối thiểu giữa các lần retry (ms)
        maxTimeout: 1000, // Thời gian chờ tối đa giữa các lần retry (ms)
      })
        .then((result) => {
          this.logger.log("Result: >>>>" + JSON.stringify(result));
          GlobalService.checkMoveTableInfobip = true;
          this.logger.log(
            chalk.blue(
              moment().format("YYYY_MM_DD HH:MM:SS") +
              " <<Start moveHistoryZalo  good end>>"
            )
          );
        })
        .catch((error) => {
          this.logger.log("Error: >>>>" + JSON.stringify(error));
          GlobalService.checkMoveTableInfobip = true;
          this.logger.log(
            chalk.blue(
              moment().format("YYYY_MM_DD HH:MM:SS") +
              " <<Start moveHistoryZalo error end>>"
            )
          );
        }).finally(() =>{
        this.logger.log(
          chalk.cyan(
            "<<*End move history Infobipp*>>"
          )
        );
      });








    }
  }

}
