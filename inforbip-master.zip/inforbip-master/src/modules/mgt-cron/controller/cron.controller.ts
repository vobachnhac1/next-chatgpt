import {
  Body,
  Controller,
  Get,
  Post,
  ValidationPipe,
  Logger,
  Res,
  HttpStatus,
  Headers,
  HttpException,
} from '@nestjs/common';
import { MgtCronService } from "../services";
import { GlobalService } from '../../../utils/global.service';
import { Cron,  SchedulerRegistry, CronExpression } from "@nestjs/schedule";


import { Response } from 'express';
import * as moment from 'moment';
import chalk from "chalk";

@Controller('cron')
export class CronController {
  constructor(
    private readonly appService:MgtCronService ,
    private schedulerRegistry: SchedulerRegistry
  ) {
  }

  private readonly logger = new Logger(CronController.name);

  @Get('infoAPI')
  getInfoAPI(): any {
    return {
      data: 'Success',
      message: '[SUCCESS]',
      status: 'SUCCESS',
    };
  }

  @Get('forceRun')
  forceRunCronJob(): any {
    let responseMessage = {
      message: '',
      status: 'FAIL',
    }

    let flagStart = false;
    let message ='';
    let dateLastStart: Date = new Date();

    try {
      const job = this.schedulerRegistry.getCronJob('CRON_INFORBIP_CREATE_QUEUE');
      if (job && job.lastDate()) {
        dateLastStart = job.lastDate();
        console.log(job.lastDate());
        job.start();
        responseMessage.message = 'Last start ' + dateLastStart + ' [SUCCESS]';
        responseMessage.status = 'SUCCESS';
      }
    }  catch (error) {
      console.log(error);
      responseMessage.message = error;
      responseMessage.status = 'FAIL';
    }


    return responseMessage;
  }

}
