import { Module } from '@nestjs/common';
import { ZeroMqModule } from '../zeromq/zeromq.module';
// import { TypeOrmModule } from '@nestjs/typeorm';
// import * as tables from './entity';
import * as controllers from './controller';
import * as services from './services';
// import * as repository from './repository';

@Module({
  // imports: [TypeOrmModule.forFeature([...Object.values(tables)])],
  controllers: Object.values(controllers),
  imports: [ZeroMqModule],
  providers: [...Object.values(services)],
})
export class MgtCronModule {}
