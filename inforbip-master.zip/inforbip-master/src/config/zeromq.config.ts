export default () => ({
  ZeroMqSocket: {
    apiKey: process.env.API_KEY || 'CHANGEME',
    reqUrl: process.env.REQ_URL || 'tcp://10.22.22.12:6868',
    pullUrl: process.env.PULL_URL || 'tcp://10.22.22.12:2706',
    reqHosUrl: process.env.REQ_URL_HOS || 'tcp://10.22.22.10:5555',
  },
});
