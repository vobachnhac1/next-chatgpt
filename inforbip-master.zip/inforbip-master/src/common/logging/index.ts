import { WinstonModule } from 'nest-winston';
const winston = require('winston');
const moment = require('moment');

// Quản lý log và xuất logger theo file mỗi ngày => server sẽ restart vào mỗi 3h sáng
export const Logger = () => {
  winston.addColors({
    error: 'red',
    warn: 'yellow',
    info: 'cyan',
    debug: 'green',
  });
  winston.format.combine(winston.format.colorize(), winston.format.simple());
  const appOptions = {
    cors: true,
    logger: WinstonModule.createLogger({
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.timestamp({
              format: 'YYYY-MM-DD HH:mm:ss:SSS',
            }),
            winston.format.printf((info) => {
              const { timestamp, level, message, context, ...args } = info;
              return `[${level}]-[${context}] ${timestamp}:  ${message} `;
            }),
          ),
        }), // ==> 1
        new winston.transports.File({
          filename:
            'logs/' + moment().format('YYYYMMDD') + '-API-INFO' + '.log',
          level: 'info',
          handleExceptions: true,
        }),
        new winston.transports.File({
          filename:
            'logs/' + moment().format('YYYYMMDD') + '-API-ERROR' + '.log',
          level: 'error',
        }),
        new winston.transports.File({
          filename:
            'logs/' + moment().format('YYYYMMDD') + '-API-DEBUG' + '.log',
          level: 'debug',
          handleExceptions: true,
        }),
      ],

      format: winston.format.combine(
        winston.format.timestamp({
          format: 'YYYY-MM-DD HH:mm:ss:SSS',
        }),
        winston.format.printf(
          (error) =>
            `${error.level.toUpperCase()}-[${error.context}]: ${[
              error.timestamp,
            ]}: ${error.message}`,
        ),
      ),
    }),
  };
  return appOptions;
};
